package com.wipro.cafe.serviceImpl;

import java.util.HashMap;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.wipro.cafe.dao.BillDao;
import com.wipro.cafe.dao.CategoryDao;
import com.wipro.cafe.dao.ProductDao;
import com.wipro.cafe.service.DashboardService;

@Service
public class DashboardServiceImpl implements DashboardService {
	
	@Autowired
	CategoryDao categoryDao;
	
	@Autowired
	ProductDao productDao;
	
	@Autowired
	BillDao billDao;
	
	@Override
	public ResponseEntity<Map<String, Object>> getDetails() {
		// TODO Auto-generated method stub
		try {
			Map<String,Object> map=new HashMap<>();
			map.put("category",categoryDao.count());
			map.put("product", productDao.count());
			map.put("bill", billDao.count());
			return new ResponseEntity<>(map,HttpStatus.OK);
		}catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
		
		return new ResponseEntity<>(new HashMap<>(),HttpStatus.INTERNAL_SERVER_ERROR);
	}

}
