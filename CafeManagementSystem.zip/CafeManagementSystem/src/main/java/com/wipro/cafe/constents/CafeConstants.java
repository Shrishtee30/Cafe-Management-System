package com.wipro.cafe.constents;

public class CafeConstants {
	public static final String SOMETHING_WENT_WRONG= "Something Went Wrong.";
	public static final String INVALID_DATA= "Invalid Data.";
	public static final String UNAUTHORIZED_ACCESS="Unauthorized access.";
	public static final String STORE_LOCATION="D:\\full stack java stack route\\cafe management system\\pdf";
	
}
