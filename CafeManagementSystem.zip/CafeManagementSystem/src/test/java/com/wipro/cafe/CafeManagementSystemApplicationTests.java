package com.wipro.cafe;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;


@RunWith(SpringRunner.class)
@SpringBootTest(classes = CafeManagementSystemApplication.class)
public class CafeManagementSystemApplicationTests {

    public CafeManagementSystemApplicationTests() {
        // constructor code here
    }

    @Test
    public void contextLoads() {
        // test code here
    }
}
