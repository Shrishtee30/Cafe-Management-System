package com.wipro.cafe;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

import java.util.List;

import javax.transaction.Transactional;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.test.context.junit4.SpringRunner;

import com.wipro.cafe.dao.UserDao;
import com.wipro.cafe.model.User;
import com.wipro.cafe.wrapper.UserWrapper;

@AutoConfigureTestDatabase(replace = AutoConfigureTestDatabase.Replace.NONE)
@RunWith(SpringRunner.class)
@DataJpaTest
@Transactional
public class UserDaoTest {

    @Autowired
    private UserDao userDao;

    private User testUser;

    @Before
    public void setup() {
        testUser = new User("testuser", "testpass", "test@test.com", "ROLE_USER");
        userDao.save(testUser);
    }

    @Test
    public void testFindByEmailId() {
        User user = userDao.findByEmailId("test@test.com");
        assertNotNull(user);
        assertEquals("testuser", user.getName());
    }

    @Test
    public void testGetAllUser() {
        List<UserWrapper> users = userDao.getAllUser();
        assertNotNull(users);
        assertEquals(4, users.size());
    }

    @Test
    public void testGetAllAdmin() {
        List<String> admins = userDao.getAllAdmin();
        assertNotNull(admins);
        assertEquals(1, admins.size());
    }

    /*@Test
    public void testUpdateStatus() {
    	  User testUser = new User("test@test.com", "password", "test user", "true");
          userDao.save(testUser);
          
          int rowsUpdated = userDao.updateStatus("true", testUser.getId());
          assertEquals(1, rowsUpdated);
          
          User updatedUser = userDao.findByEmailId("test@test.com");
          assertEquals("true", updatedUser.getStatus());
    }*/

    @Test
    public void testFindByEmail() {
        User user = userDao.findByEmail("test@test.com");
        assertNotNull(user);
        assertEquals("testuser", user.getName());
    }
}
