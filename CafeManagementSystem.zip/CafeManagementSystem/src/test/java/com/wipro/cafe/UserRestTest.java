package com.wipro.cafe;

import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.when;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.web.client.RestTemplate;

import com.wipro.cafe.model.User;
import com.wipro.cafe.restImpl.UserRestImpl;
import com.wipro.cafe.service.UserService;
import com.wipro.cafe.wrapper.UserWrapper;

@RunWith(SpringRunner.class)
public class UserRestTest {
    	
	    @Mock
	    private UserService userService;
	    
	    @InjectMocks
	    private UserRestImpl userRest;
	    
	    @Before
	    public void setup() {
	        MockitoAnnotations.initMocks(this);
	    }
	    
	    @Test
	    public void testSignUp() {
	        Map<String, String> requestMap = new HashMap<>();
	        requestMap.put("username", "testuser");
	        requestMap.put("password", "testpass");
	        when(userService.signUp(requestMap)).thenReturn(ResponseEntity.ok("User signed up successfully"));
	        ResponseEntity<String> response = userRest.signUp(requestMap);
	        assertEquals(HttpStatus.OK, response.getStatusCode());
	        assertEquals("User signed up successfully", response.getBody());
	    }
	    
	    @Test
	    public void testLogin() {
	        Map<String, String> requestMap = new HashMap<>();
	        requestMap.put("username", "testuser");
	        requestMap.put("password", "testpass");
	        when(userService.login(requestMap)).thenReturn(ResponseEntity.ok("User logged in successfully"));
	        ResponseEntity<String> response = userRest.login(requestMap);
	        assertEquals(HttpStatus.OK, response.getStatusCode());
	        assertEquals("User logged in successfully", response.getBody());
	    }
	    
	   
	    @Test
	    public void testUpdate() {
	        Map<String, String> requestMap = new HashMap<>();
	        requestMap.put("username", "testuser");
	        requestMap.put("password", "newpass");
	        when(userService.update(requestMap)).thenReturn(ResponseEntity.ok("User updated successfully"));
	        ResponseEntity<String> response = userRest.update(requestMap);
	        assertEquals(HttpStatus.OK, response.getStatusCode());
	        assertEquals("User updated successfully", response.getBody());
	    }
	    
	    @Test
	    public void testCheckToken() {
	        when(userService.checkToken()).thenReturn(ResponseEntity.ok("Token is valid"));
	        ResponseEntity<String> response = userRest.checkToken();
	        assertEquals(HttpStatus.OK, response.getStatusCode());
	        assertEquals("Token is valid", response.getBody());
	    }
	    
	    @Test
	    public void testChangePassword() {
	        Map<String, String> requestMap = new HashMap<>();
	        requestMap.put("username", "testuser");
	        requestMap.put("oldPassword", "testpass");
	        requestMap.put("newPassword", "newpass");
	        when(userService.changePassword(requestMap)).thenReturn(ResponseEntity.ok("Password changed successfully"));
	        ResponseEntity<String> response = userRest.changePassword(requestMap);
	        assertEquals(HttpStatus.OK, response.getStatusCode());
	        assertEquals("Password changed successfully", response.getBody());
	    }
	    
	    @Test
	    public void testForgotPassword() {
	        Map<String, String> requestMap = new HashMap<>();
	        requestMap.put("username", "testuser");
	        when(userService.forgotPassword(requestMap)).thenReturn(ResponseEntity.ok("Password reset link sent"));
	        ResponseEntity<String> response = userRest.forgotPassword(requestMap);
	        assertEquals(HttpStatus.OK, response.getStatusCode());
	        assertEquals("Password reset link sent", response.getBody());
	    }
}
