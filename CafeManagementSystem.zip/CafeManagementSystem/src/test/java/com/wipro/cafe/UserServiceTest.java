package com.wipro.cafe;

import org.junit.runner.RunWith;
import org.springframework.test.context.junit4.SpringRunner;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.junit.Before;
import org.junit.Test;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import com.wipro.cafe.rest.UserRest;
import com.wipro.cafe.service.UserService;
import com.wipro.cafe.wrapper.UserWrapper;

public class UserServiceTest {
	private UserService userService;


    @Before
    public void setUp() {
        userService = mock(UserService.class);
    }

    @Test
    public void testSignUp() {
        Map<String, String> requestMap = new HashMap<>();
        requestMap.put("email", "test@test.com");
        requestMap.put("password", "password");
        when(userService.signUp(requestMap)).thenReturn(new ResponseEntity<>("User created", HttpStatus.OK));
        ResponseEntity<String> responseEntity = userService.signUp(requestMap);
        assertEquals(HttpStatus.OK, responseEntity.getStatusCode());
        assertEquals("User created", responseEntity.getBody());
    }

    @Test
    public void testLogin() {
        Map<String, String> requestMap = new HashMap<>();
        requestMap.put("email", "test@test.com");
        requestMap.put("password", "password");
        when(userService.login(requestMap)).thenReturn(new ResponseEntity<>("Login successful", HttpStatus.OK));
        ResponseEntity<String> responseEntity = userService.login(requestMap);
        assertEquals(HttpStatus.OK, responseEntity.getStatusCode());
        assertEquals("Login successful", responseEntity.getBody());
    }

   /* @Test
    public void testGetAllUser() {
        List<UserWrapper> users = new ArrayList<>();
        users.add(new UserWrapper(1, "test1@test.com", "active"));
        users.add(new UserWrapper(2, "test2@test.com", "inactive"));
        when(userService.getAllUser()).thenReturn(new ResponseEntity<>(users, HttpStatus.OK));
        ResponseEntity<List<UserWrapper>> responseEntity = userService.getAllUser();
        assertEquals(HttpStatus.OK, responseEntity.getStatusCode());
        assertEquals(2, responseEntity.getBody().size());
    }*/

    @Test
    public void testUpdate() {
        Map<String, String> requestMap = new HashMap<>();
        requestMap.put("id", "1");
        requestMap.put("email", "test1@test.com");
        requestMap.put("status", "inactive");
        when(userService.update(requestMap)).thenReturn(new ResponseEntity<>("User updated", HttpStatus.OK));
        ResponseEntity<String> responseEntity = userService.update(requestMap);
        assertEquals(HttpStatus.OK, responseEntity.getStatusCode());
        assertEquals("User updated", responseEntity.getBody());
    }

    @Test
    public void testCheckToken() {
        when(userService.checkToken()).thenReturn(new ResponseEntity<>("Token is valid", HttpStatus.OK));
        ResponseEntity<String> responseEntity = userService.checkToken();
        assertEquals(HttpStatus.OK, responseEntity.getStatusCode());
        assertEquals("Token is valid", responseEntity.getBody());
    }

    @Test
    public void testChangePassword() {
        Map<String, String> requestMap = new HashMap<>();
        requestMap.put("email", "test@test.com");
        requestMap.put("oldPassword", "password");
        requestMap.put("newPassword", "newPassword");
        when(userService.changePassword(requestMap)).thenReturn(new ResponseEntity<>("Password changed", HttpStatus.OK));
        ResponseEntity<String> responseEntity = userService.changePassword(requestMap);
        assertEquals(HttpStatus.OK, responseEntity.getStatusCode());
        assertEquals("Password changed", responseEntity.getBody());
    }

   /* @Test
    public void testForgotPassword() {
    	 Map<String, String> requestMap = new HashMap<>();
         requestMap.put("email", "test@test.com");
         ResponseEntity<String> responseEntity = userService.forgotPassword(requestMap);
         assertEquals(HttpStatus.OK, responseEntity.getStatusCode());
         assertTrue(responseEntity.getBody().contains("Password reset instructions sent to your email"));
    }*/


}
